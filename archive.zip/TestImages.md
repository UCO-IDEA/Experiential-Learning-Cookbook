If you want to embed images, this is how you do it:

![Image of Yaktocat](https://octodex.github.com/images/yaktocat.png)

![image digital poster](/DigitalPoster-Header.png)

![Digital Poster image inside of the digital poster folder ](/Assets/Digital%20poster/DigitalPoster-Header.png)

![Digital Poster Image Experience Map](/assets/Digital%20Poster/ExperienceMap-Developer.png)

