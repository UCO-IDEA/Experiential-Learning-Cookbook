# Table of Contents

1. [Intro to the Lumina Foundation Experiential Learning Assignment](intro.md)
1. [Project Ingredient](ingredients.md)
1. [The Tier System](tiers.md)
1. [Expected Outcome Assessment](outcomes.md)
1. [Digital Poster](poster.md)
1. [Persuasive Speech](speech.md)
1. [Forward](forward.md)
1. [Interactive Essay](essay.md)
1. [How it Works](howItWorks.md)
1. [Survey Results](surveys.md)





