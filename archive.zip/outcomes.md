# Expected Outcome Assessment

 ## Were these outcomes obtained?

* Provided a collaborative experience for faculty and students
* Engineered an experience with opportunities for faculty to mentor students
 * Supported faculty in their efforts to enhance learning inside and outside of the classroom
   * Brought research about facilitating learning to the attention of the university community
   * Advocated and recognized teaching excellence
   * Acted as a resource for faculty as they planned, implemented, enhanced, and assessed student learning
   * Promoted the teacher-scholar model of faculty excellence within UCO’s ethos of providing transformative learning opportunities for our students

