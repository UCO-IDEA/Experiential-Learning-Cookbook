
![Digital Poster Image](/Assets/ImagesForTools/DigitalPoster-Header.png)

# Digital Poster

This tool allows students to take their poster design and turn it into its own presentation. Giving them the ability to add text, pictures, links, and videos to tell their story for them.

## Concept

Professor Trevor Cox came up with Digital Poster for his Organizational Leadership Capstone course. His goal was to take the existing poster presentation assignment being done on actual poster paper and make it virtual.

<br>

## How It Works

<img style='margin-bottom:20px;' align="right" width="500" height="250" src="https://raw.githubusercontent.com/UCO-IDEA/ExperientialLearningCookbook/main/Assets/ImagesForTools/Poster-Concept-image.jpg">


### Upload your Poster
A student inserts a link to the poster image that they created to serve as the background for their poster presentation.


### Add your content
The student then uses Digital Poster to add annotation boxes wherever they desire. They then fill those boxes with the text, images, links, and videos they need in order to effectively present their topic.

<img style='margin-bottom:20px;' align="right" width="500" height="300" src="https://raw.githubusercontent.com/UCO-IDEA/ExperientialLearningCookbook/main/Assets/ImagesForTools/DigitalPoster-Screenshot-2.png">

### Publish your poster
The student then finalizes their poster presentation, receives a link to their web hosted poster, and then shares the link with their peers and professor. With that link, they can experience the poster presentation and explore it while allowing the poster to present itself.

## Documentation

**[Instructions PDF](https://cece.uco.edu/idea/PosterPresentation/instructions/Digital%20Poster%20Instructions.pdf)**

**Video Instructions**
* [Plan](https://www.youtube.com/watch?v=8RfNHcPlm98&feature=youtu.be&ab_channel=CeCEIDEA)
* [Create Poster Graphics](https://www.youtube.com/watch?v=k4n-gRexNM0&feature=youtu.be&ab_channel=CeCEIDEA)
* [Edit Mode](https://www.youtube.com/watch?v=q88ZAkxwXNU&feature=youtu.be&ab_channel=CeCEIDEA)[	](https://www.youtube.com/watch?v=q88ZAkxwXNU&feature=youtu.be&ab_channel=CeCEIDEA)
* [Preview Mode](https://www.youtube.com/watch?v=HcFy1pUPfAM&feature=youtu.be&ab_channel=CeCEIDEA)
* [Display your Poster](https://www.youtube.com/watch?v=Vd-aePfec1U)
* [Visit a Classmates Poster](https://www.youtube.com/watch?v=-SiugR2sEtQ&feature=youtu.be)

### Process Map for Developers

![Digital Poster Image Experience Map](/Assets/ImagesForTools/Developer.png)

### Process Map for Instructors

![Digital Poster Image Experience Map](/Assets/ImagesForTools/DigitalPoster-ExperienceMap-Instructor%20(2).jpg)

### Process Map for Students

![Digital Poster Image Experience Map](/Assets/ImagesForTools/DigitalPoster-ExperienceMap-Student%20(1).jpg)
